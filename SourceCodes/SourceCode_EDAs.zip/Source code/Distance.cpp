//
//  Distances.cpp
//  RankingEDAsCEC
//
//  Created by Josu Ceberio Uribe on 11/19/13.
//  Copyright (c) 2013 Josu Ceberio Uribe. All rights reserved.
//


#include "Distance.h"

/*
 * The constructor.
 */
Distance_Model::Distance_Model()
{
	
}

/*
 * The destructor.
 */
Distance_Model::~Distance_Model()
{

}
