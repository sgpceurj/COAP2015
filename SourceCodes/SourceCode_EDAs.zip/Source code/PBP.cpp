/*
 *  PBP.cpp
 *  RankingEDAsCEC
 *
 *  Created by Josu Ceberio Uribe on 7/11/13.
 *  Copyright 2013 University of the Basque Country. All rights reserved.
 *
 */

#include "PBP.h"

/*
 * The constructor.
 */
PBP::PBP()
{
	
}

/*
 * The destructor. It frees the memory allocated.
 */
PBP::~PBP()
{

}
