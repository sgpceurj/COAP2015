/*
 *  RankingEDA.cpp
 *  RankingEDAsCEC
 *
 *  Created by Josu Ceberio Uribe on 9/15/11.
 *  Copyright 2011 University of the Basque Country. All rights reserved.
 *
 */

#include "RankingEDA.h"
#include "MallowsModel.h"
#include "Cayley.h"
#include "Kendall.h"
#include "GeneralizedMallowsModel.h"

/*
 * The constructor.
 */
RankingEDA::RankingEDA(PBP * problem, int problem_size, long int max_evaluations, char* model_type, char* metric_type, int inverse)
{
    //1. standard initializations
    m_problem=problem;
    m_problem_size=problem_size;
    m_max_evaluations=max_evaluations;
    m_evaluations=0;
    m_convergence_evaluations=0;
    m_best= new CIndividual(problem_size);
    m_best->SetValue(MIN_LONG_INTEGER);
    m_pop_size=m_problem_size*10;
    m_sel_size=m_problem_size;
    m_offspring_size= m_pop_size-1;
    memcpy(m_metric_type,metric_type,sizeof(char)*10);
    memcpy(m_model_type,model_type,sizeof(char)*10);
    
    m_inverse=inverse;
    
    //2. initialize the population
    m_population= new CPopulation(m_pop_size, m_offspring_size,m_problem_size);
    int * genes= new int[m_problem_size];
    for(int i=0;i<m_pop_size;i++)
	{
		//Create random individual
		GenerateRandomPermutation(genes,m_problem_size);
        if (m_inverse)
            m_population->SetToPopulation(genes, i, m_problem->EvaluateInv(genes));
        else
            m_population->SetToPopulation(genes, i, m_problem->Evaluate(genes));
        m_evaluations++;
    }
    
    m_population->SortPopulation(0);
    //cout<<""<<m_population->m_individuals[0]->Value()<<" , "<<m_evaluations<<" , "<<m_max_evaluations-m_evaluations<<endl;
    delete [] genes;
    
    
    //3. Build model structures
    if (((string)model_type)=="M"){
        m_model=new CMallowsModel(m_problem_size, m_sel_size, metric_type);
    
    }
    else if (((string)model_type)=="GM")
    {
        m_model=new CGeneralizedMallowsModel(m_problem_size, m_sel_size, metric_type);
    }
 
    
    
}

/*
 * The destructor. It frees the memory allocated..
 */
RankingEDA::~RankingEDA()
{
    delete m_best;
    delete m_population;
    delete m_model;
}


/*
 * Experiment for the Metric suitability for the different problems.
 */
void RankingEDA::MetricSuitability_Experiment(char * results_file){

    int tests=1000;
    int samples=1000;
    int * consensus= new int[m_problem_size];
    double thetas_K[10]={1.48,1.8,2.08,2.33,2.6,2.9,3.28,3.75,4.5,10};
    double thetas_C[10]={2.85,3.25,3.56,3.85,4.15,4.47,4.83,5.3,6.1,12};
    double thetas_U[10]={3.3,3.75,4.1,4.4,4.7,5.02,5.4,5.9,6.7,12};
    double theta=0;
    int distance_max_K=(m_problem_size-1)*m_problem_size/2;
    int distance_max_C=m_problem_size-1;
    int distance_max_U=m_problem_size-1;
    int distance=0;
    double fitness_variation=0;
    int fitness_differential=0;
    int distance_max;
    
    int * sample= new int[m_problem_size];
    double total_tests=0;
   // ofstream output_file;
   // output_file.open(results_file);
    for (int j=0;j<10;j++){
        
        if (((string)m_metric_type)=="K")
            theta=thetas_K[j];
        else if (((string)m_metric_type)=="C")
            theta=thetas_C[j];
        else
            theta=thetas_U[j];
        total_tests=0;
        for (int i=0;i<tests;i++){
            fitness_variation=0;
            GenerateRandomPermutation(consensus, m_problem_size);
            m_model->Learn(consensus, theta);
        
            for (int z=0;z<samples;z++){
                m_model->Sample(sample);
                
                //distance of the samples solution with respect to the consensus ranking.
                if (((string)m_metric_type)=="K"){
                    distance = Kendall(consensus,sample,m_problem_size);
                    distance_max=distance_max_K;
                }
                else if (((string)m_metric_type)=="C"){
                    distance = Cayley(consensus,sample,m_problem_size);
                    distance_max=distance_max_C;
                }
                else{
                    distance = Ulam(consensus,sample,m_problem_size);
                    distance_max=distance_max_U;
                }
                
                //fitness differential
                fitness_differential=abs(m_problem->EvaluateInv(sample)-m_problem->EvaluateInv(consensus));
                fitness_variation+=fitness_differential*(1-distance/distance_max);
            }
            fitness_variation=fitness_variation/samples;
            total_tests+=fitness_variation;
            //cout<<fitness_variation<<endl;
        }
        total_tests=total_tests/tests;
        cout<<total_tests<<endl;
    }
    cout<<"--------------------------------"<<endl;
 //   output_file.close();
    delete [] consensus;
    delete [] sample;
    
}

/*
 * Running function
 */
int RankingEDA::Run(){
    
    //cout<<"Running..."<<endl;
    //variable initializations.
    int i;
    long int newScore;
    int * genes= new int[m_problem_size];
    int iterations=1;
    float rate=0.001;

    //EDA iteration. Stopping criterion is the maximum number of evaluations performed
    while (m_evaluations<m_max_evaluations){

        //learn model
        m_model->Learn(m_population, m_sel_size);

        //sample the model.
        for (i=0;i< m_offspring_size && m_evaluations<m_max_evaluations;i++){
            //distance at which the sampled solution is from the consensus ranking.
            
            
            m_model->Sample(genes);
            
           if (m_inverse)
                m_population->AddToPopulation(genes, i, m_problem->EvaluateInv(genes));
            else
                m_population->AddToPopulation(genes, i, m_problem->Evaluate(genes));
            m_evaluations++;
        }

        
        //update the model.
        m_population->SortPopulation(1);

        //update indicators
        newScore=m_population->m_individuals[0]->Value();
        float modification=0;
        if (newScore>m_best->Value())
        {
            
            m_best->SetGenes(m_population->m_individuals[0]->Genes());
            m_best->SetValue(newScore);
            m_convergence_evaluations=m_evaluations;
          /* if (((string)m_model_type)=="M")
                cout<<""<<m_population->m_individuals[0]->Value()<<" , "<<m_evaluations<<" , "<<m_max_evaluations-m_evaluations<<"  Theta. "<<((CMallowsModel*)m_model)->m_distance_model->m_theta_parameter<<" lower: "<<((CMallowsModel*)m_model)->m_distance_model->m_lower_theta_bound<<endl;

            else
                cout<<""<<m_population->m_individuals[0]->Value()<<" , "<<m_evaluations<<" , "<<m_max_evaluations-m_evaluations<<"  Thetas. "<<((CGeneralizedMallowsModel*)m_model)->m_distance_model->m_theta_parameters[0]<<" lower: "<<((CGeneralizedMallowsModel*)m_model)->m_distance_model->m_lower_theta_bound<<endl;
        */
           modification=-rate;
        }
        else{
            modification=rate;
        }
    
        if (((string)m_model_type)=="M"){
            ((CMallowsModel*)m_model)->m_distance_model->m_lower_theta_bound= ((CMallowsModel*)m_model)->m_distance_model->m_lower_theta_bound+modification;
            if (((CMallowsModel*)m_model)->m_distance_model->m_lower_theta_bound<0.001)
                ((CMallowsModel*)m_model)->m_distance_model->m_lower_theta_bound=0.001;
        }
        else{
            ((CGeneralizedMallowsModel*)m_model)->m_distance_model->m_lower_theta_bound= ((CGeneralizedMallowsModel*)m_model)->m_distance_model->m_lower_theta_bound+modification;
            if (((CGeneralizedMallowsModel*)m_model)->m_distance_model->m_lower_theta_bound<0.001)
            ((CGeneralizedMallowsModel*)m_model)->m_distance_model->m_lower_theta_bound=0.001;
        }
       

        iterations++;

    }
    delete [] genes;
    
    return 0;
}

/*
 * Returns the number of performed evaluations.
 */
int RankingEDA::GetPerformedEvaluations(){
    return m_convergence_evaluations;
}

/*
 * Returns the fitness of the best solution obtained.
 */
long int RankingEDA::GetBestSolutionFitness(){
    return m_best->Value();
}

/*
 * Returns the best solution obtained.
 */
CIndividual * RankingEDA::GetBestSolution(){
    return m_best;
}


/*
 * This method applies a swap of the given i,j positions in the array.
 */
void RankingEDA::Swap(int * array, int i, int j)
{
	int aux=array[i];
	array[i]=array[j];
	array[j]=aux;
}
