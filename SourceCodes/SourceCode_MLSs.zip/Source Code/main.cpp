//
//  main.cpp
//  LocalSearchForLOP
//
//  Created by Josu Ceberio Uribe on 7/16/13.
//  Copyright (c) 2013 Josu Ceberio Uribe. All rights reserved.
//
#include <iostream>
#include <string.h>
#include "string.h"
#include <stdlib.h>
#include <sys/time.h>
#include <vector>
#include <stdio.h>
#include <fstream>
#include <iostream>
#include <iomanip>
#include "PBP.h"
#include "PFSP.h"
#include "LOP.h"
#include "QAP.h"
#include "TSP.h"
#include "LocalOptima.h"
#include "Tools.h"
#include "PermutationTools.h"
#include "LocalSearch.h"


using std::istream;
using std::ostream;
using namespace std;


//It is the instance of the problem to optimize.
PBP * PROBLEM;

//The type of the problem to solve.
char PROBLEM_TYPE[10];

//The neighborhood of the local search.
int NEIGHBORHOOD;

// The individual size.
int PROBLEM_SIZE;

// Number of evaluations performed.
long int EVALUATIONS = 0;

// Convergence evaluation of the best fitness.
long int CONVERGENCE_EVALUATIONS = 0;

// Maximum number of evaluations allowed performed.
long int MAX_EVALUATIONS = 0;

// Name of the file where the result will be stored.
char RESULTS_FILENAME[50];

// Name of the file where the instances is stored.
char INSTANCE_FILENAME[50];

// The seed asigned to the process
int SEED;


/*
 * Get next command line option and parameter
 */
int GetOption (int argc, char** argv, char* pszValidOpts, char** ppszParam)
{
	
    static int iArg = 1;
    char chOpt;
    char* psz = NULL;
    char* pszParam = NULL;
	
    if (iArg < argc)
    {
        psz = &(argv[iArg][0]);
		
        if (*psz == '-' || *psz == '/')
        {
            // we have an option specifier
            chOpt = argv[iArg][1];
			
            if (isalnum(chOpt) || ispunct(chOpt))
            {
                // we have an option character
                psz = strchr(pszValidOpts, chOpt);
				
                if (psz != NULL)
                {
                    // option is valid, we want to return chOpt
                    if (psz[1] == ':')
                    {
                        // option can have a parameter
                        psz = &(argv[iArg][2]);
                        if (*psz == '\0')
                        {
                            // must look at next argv for param
                            if (iArg+1 < argc)
                            {
                                psz = &(argv[iArg+1][0]);
                                if (*psz == '-' || *psz == '/')
                                {
                                    // next argv is a new option, so param
                                    // not given for current option
                                }
                                else
                                {
                                    // next argv is the param
                                    iArg++;
                                    pszParam = psz;
                                }
                            }
                            else
                            {
                                // reached end of args looking for param
                            }
							
                        }
                        else
                        {
                            // param is attached to option
                            pszParam = psz;
                        }
                    }
                    else
                    {
                        // option is alone, has no parameter
                    }
                }
                else
                {
                    // option specified is not in list of valid options
                    chOpt = -1;
                    pszParam = &(argv[iArg][0]);
                }
            }
            else
            {
                // though option specifier was given, option character
                // is not alpha or was was not specified
                chOpt = -1;
                pszParam = &(argv[iArg][0]);
            }
        }
        else
        {
            // standalone arg given with no option specifier
            chOpt = 1;
            pszParam = &(argv[iArg][0]);
        }
    }
    else
    {
        // end of argument list
        chOpt = 0;
    }
	
    iArg++;
	
    *ppszParam = pszParam;
    return (chOpt);
}

/*
 * Help command output.
 */
void usage(char *progname)
{
    cout << "Algorithm -i <instance_name> -o <results_name> -s <seed> -t <problem_type> -n <neighborhood>" <<endl;
    cout <<"   -i File name of the instance.\n"<<endl;
    cout <<"   -o Name of the file to store the results.\n"<<endl;
    cout <<"   -s Seed to be used for pseudo-random numbers generator.\n"<<endl;
    cout <<"   -t problem_type (TSP, QAP, LOP, PFSP or API).\n"<<endl;
    cout <<"   -n neighborhood (1 (Adjacent swap), 2 (Swap), 3 (Insert)).\n"<<endl;
}

/*
 * Obtaint the execution parameters from the command line.
 */
bool GetParameters(int argc,char * argv[])
{
	char c;
    if(argc==1)
    {
    	usage(argv[0]);
        return false;
    }
	char** optarg;
	optarg = new char*[argc];
    while ((c = GetOption (argc, argv, "s:t:n:o:i:",optarg)) != '\0')
    {
    	switch(c)
    	{
                usage(argv[0]);
                return false;
                break;
                
            case 's' :
                SEED = atoi(*optarg);
                break;
				
           	case 't':
                strcpy(PROBLEM_TYPE, *optarg);
                break;
                
            case 'o' :
                strcpy(RESULTS_FILENAME, *optarg);
                break;
                
			case 'i':
                strcpy(INSTANCE_FILENAME, *optarg);
                break;

           	case 'n':
                NEIGHBORHOOD=atoi(*optarg);
                break;

            default:
                cout<<"Wrong parameters"<<endl;
                exit(1);
                
		}
    }
    
    delete [] optarg;
    
	return true;
}


/*
 * Reads the problem info of the instance set.
 */
PBP * GetProblemInfo(string problemType, string filename)
{
    PBP * problem;
    if (problemType=="PFSP")
        problem= new PFSP();
    else if (problemType=="TSP")
        problem= new TSP();
    else if (problemType=="QAP")
        problem= new QAP();
    else if (problemType=="LOP")
        problem= new LOP();
    else{
        cout<<"Wrong problem type was specified."<<endl;
        exit(1);
    }
    
    //Read the instance.
    int problem_size= problem->Read(filename);
    PROBLEM_SIZE=problem_size;
    
	return problem;
}

/*
 * Writes the results of the execution.
 */
void WriteResults(double best_fitness, int * best, long int evaluations, long double time_interval){
    
    ofstream output_file;
    output_file.open(RESULTS_FILENAME);
    output_file<<"Best fitness: "<< setprecision(15)<<best_fitness<<endl;
    output_file<<"Best solution: ";
    for (int i=0;i<PROBLEM_SIZE;i++)
        output_file<<best[i]<<" ";
    output_file<<endl;
    output_file<<"Evaluations performed: "<<setprecision(15)<<evaluations<<endl;
    output_file<<"Time consumed: "<<time_interval<<endl;
    output_file.close();
}


int main(int argc, char * argv[])
{
    //Initialize time variables.
    struct timeval tim;
    gettimeofday(&tim, NULL);
    double t1=tim.tv_sec+(tim.tv_usec/1000000.0);
    
    //Get parameters
	if(!GetParameters(argc,argv)) return -1;
    
    //Set seed
    srand(SEED*1000);
    
    //Read the problem instance to optimize.
	PROBLEM = GetProblemInfo(PROBLEM_TYPE,INSTANCE_FILENAME);
    MAX_EVALUATIONS=PROBLEM_SIZE*PROBLEM_SIZE*1000;
    
    //Create the file to store the results.
    ofstream output_file;
    output_file.open(RESULTS_FILENAME);
    output_file.close();
    
    LocalSearch * algorithm= new LocalSearch(PROBLEM, PROBLEM_SIZE, NEIGHBORHOOD, MAX_EVALUATIONS);
    
    
    ///Calculating attraction basin.
    /*vector<LocalOptima*> localoptima=algorithm->Calculate_AttBasin();
    ofstream results_file;
    results_file.open(RESULTS_FILENAME);
    results_file<<localoptima.size()<<endl;
    for (int i=0;i<localoptima.size();i++){
        results_file<<localoptima[i]->fitness<<";"<<localoptima[i]->attraction_basin<<";[";
        for (int j=0;j<PROBLEM_SIZE;j++){
            results_file<<setprecision(15)<<localoptima[i]->genes[j]<<" ";
        }
        results_file<<"]"<<endl;
    }
    results_file.close();

    
    exit(1);*/
    
    int * optimum = new int[PROBLEM_SIZE];
    GenerateRandomPermutation(PROBLEM_SIZE, optimum);
    LocalOptima * local_optima_best= new LocalOptima(PROBLEM_SIZE);
    algorithm->Run_Flagged(optimum,local_optima_best);
    //cout<<fitness_opt<<", "<<MAX_EVALUATIONS-algorithm->m_evaluations<<endl;

    LocalOptima * local_optima_prov= new LocalOptima(PROBLEM_SIZE);
    int * solution= new int[PROBLEM_SIZE];
    do{
        GenerateRandomPermutation(PROBLEM_SIZE, solution);
        algorithm->Run_Flagged(solution,local_optima_prov);
        if (local_optima_prov->fitness>local_optima_best->fitness)
        {
            memcpy(local_optima_best->genes, local_optima_prov->genes, sizeof(int)*PROBLEM_SIZE);
            local_optima_best->fitness=local_optima_prov->fitness;
            //cout<<setprecision(15)<<local_optima_prov->fitness<<", "<<MAX_EVALUATIONS-algorithm->m_evaluations<<endl;
        }
    } while(algorithm->m_evaluations<MAX_EVALUATIONS);
    
    gettimeofday(&tim, NULL);
    double t2=tim.tv_sec+(tim.tv_usec/1000000.0);
    WriteResults(local_optima_best->fitness,optimum,algorithm->m_evaluations,t2-t1);
    
    delete algorithm;
    delete [] optimum;
    delete [] solution;
    return 0;
}

